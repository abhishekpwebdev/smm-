<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
		<title>SocialKhalifa</title>
		
		<!-- css -->
		
		<!--  google fonts  -->
		

		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="css/animate.css">
		<link rel="stylesheet" type="text/css" href="css/custom.css">

	</head>

	<body onload="countdown(year,month,day,hour,minute)">
	
		<div class="body-wrapper">

			<!--   begin of header section   -->
			<section class="header" id="overlay-1">
				<div class="header-wrapper">
					<div class="container">
						<div class="row">
							<div class="col-md-8 col-md-offset-2 text-center">
								<div class="theme-name">
                                        <img src="img/ logo.png" alt="logo"  />
                                          <p> A social Media Management Tool</p><br>
                                          <p>With No Limitation</p>
									
								</div>
							</div>
							</div>
							</div> <br>
							<div class="container">
						
						<div class="row">
							<div class="col-md-12 text-center">
								<div class="header-text">
									 
									<p class="coming">coming soon</p>
								</div>
							</div>
							</div>
							<div class="row">
					<div class="col-md-12 text-center">
					<div class="zoom">
						
					<h2>Why Social Khalifa?</h2>

                    <ul class="a">
                      <li style="text-align: left"> Pay Per Feature</li>
                        <li style="text-align: left">Unlimited Social Media Accounts <br> & Scheduling  </li>
                         <li style="text-align: left"> Affordable Pricing </li>
                      </ul>  

					</div>

					</div>

                   </div>
						</div>
						

						
					<!--  end of .container  --> 
					
					
					
				</div><!-- end of .header-wrapper  -->

			</section>
			<!--   end of header section     -->
			<br><br>

			<!--   begin of newsletter section  -->
			<section class="newsletter text-center">
				<div class="newsletter-wrapper">
					<div class="container">
					<div class="row">
					<h1 class="text" align="text-left">get prelaunch benefits </h1>

					</div>
						<div class="row">
							<h2 class="newsletter-text" align="text-left" >subscribe and be in the loop</h2>
							<div class="col-md-8 col-md-offset-2">
								<form>
	  								<div class="form-group">
	    								<div class="input-group">
	      									<div class="input-group-addon"><i class="fa fa-envelope-o"></i></div>
	      									<input type="email" class="form-control" placeholder="Enter Your Email Here...">
	    								</div>
	    								<button class="subsribe-btn">Subscribe Now</button>
	  								</div>
								</form>
								<p class="spam">
									<i class="fa fa-bookmark"></i>We'll never spam you.
								</p>
							</div>
						</div>
					</div><!--  end of .container  -->
				</div> <!--  end of .newssletter-wrapper  -->
			</section>
			<!--   end of newsletter section  -->
			<!--  begin of counter  -->

						<div class="row">
							<div class="col-md-12">
								<div class="numbers" id="count2"></div>
							</div>
							<div class="col-md-12 counter1 text-center" id="spacer1">
								<div class="col-md-4 col-xs-3 col-sm-4 day numbers" id="dday"></div>
								<div class="col-md-2 col-xs-3 col-sm-2 hr numbers" id="dhour"></div>
								<div class="col-md-2 col-xs-3 col-sm-2 min numbers" id="dmin"></div>
								<div class="col-md-4 col-xs-3 col-sm-4 sec numbers" id="dsec"></div>
							</div>
							<div class="col-md-12 counter2 text-center" id="spacer2">
								<div class="col-md-4 col-xs-3 col-sm-4 day title" id="days">day</div>
								<div class="col-md-2 col-xs-3 col-sm-2 hr title" id="hours">hr</div>
								<div class="col-md-2 col-xs-3 col-sm-2 min title" id="minutes">min</div>
								<div class="col-md-4 col-xs-3 col-sm-4 sec title" id="seconds">sec</div>
							</div>
						</div>
						<!--  end of counter -->

			<!--   begin of social-media section  -->
			<section class="social-media text-center">
				<div class="social-media-wrapper">
					<div class="container">
						<div class="row">
							<h2 class="social-media-text">poke us</h2>
							<div class="col-md-8 col-md-offset-2">
								<div class="social-links">
									<a target="_blank" href="#" title="Facebook">
										<i class="fa fa-facebook"></i>
									</a>
									<a target="_blank" href="#" title="Twitter">
										<i class="fa fa-twitter"></i>
									</a>
									<a target="_blank" href="#" title="Google+">
										<i class="fa fa-google-plus"></i>
									</a>
									<a target="_blank" href="#" title="Pinterest">
										<i class="fa fa-pinterest"></i>
									</a>
									<a target="_blank" href="" title="Instagram">
										<i class="fa fa-instagram"></i>
									</a>
								</div>
							</div>
							<div class="clear-fix"></div>
						</div>
					</div>
				</div><!--  end of .social-media-wrapper  -->
			</section>
			<!--   end of social-media section   -->

			<!--   begin of footer  section  -->
			<section class="footer">
				<div class="footer-wrapper">
					<div class="container">
						<div class="row">
							<div class="col-md-6">
								<p class="copy-right text-center">&copy; 2018 SocialKhalifa  All rights reserved.</p>
							</div>
							
						</div>
					</div>
				</div><!--  end of .footer-wrapper  -->
			</section>
			<!--   end of footer section  -->
		</div>

		            ?>
		<!--  js files -->

		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/timer.js"></script>
		<script type="text/javascript" src="js/script.js"></script>



	
	</body>
</html>